$(document).ready(function() {
  $('#orderForm').submit(function(e) {
    e.preventDefault();

    const name = $('input[name="name"]').val();
    const flavor = $('select[name="flavor"]').val();
    const quantity = $('input[name="quantity"]').val();

    // Create email parameters
    const templateParams = {
      customer_name: name,
      order_flavor: flavor,
      order_quantity: quantity
    };

    emailjs.send("YOUR_SERVICE_ID", "YOUR_TEMPLATE_ID", templateParams)
      .then(function(response) {
        $('#orderMessage').text(`✅ Thank you, ${name}! Your ${quantity} ${flavor} wings order has been received!`);
      }, function(error) {
        $('#orderMessage').text("❌ Sorry, something went wrong. Please try again.");
        console.error(error);
      });

    $('#orderForm')[0].reset();
  });
});
